using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Begin : MonoBehaviour
{
    private Text startText;

    private void Start()
    {
        startText = GetComponent<Text>();
        startText.enabled = true;
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            startText.enabled = false;
        }
    }
}
