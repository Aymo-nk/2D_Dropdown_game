using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine;


public class EnemyOne : MonoBehaviour
{
    public float monsterMovementVelocity = 2f;
    private bool right = true;
    private Rigidbody2D rigidBody;
    public float maximumposXaxis = 4f;
    public float minimumposXaxis = -4f;
    public float gamereset = 3f;
    
    private SpriteRenderer sprite;

    // Start is called before the first frame update
    void Start()
    {
        
        rigidBody = GetComponent<Rigidbody2D>();
        sprite = GetComponent<SpriteRenderer>();
        sprite.flipX = true;
    }

    // Update is called once per frame
    void Update()
    {

    }
    private void FixedUpdate()
    {
        int movementDirection = right ? 1 : -1;
        float movement = monsterMovementVelocity * movementDirection * Time.fixedDeltaTime;
        rigidBody.MovePosition(rigidBody.position + new Vector2(movement, 0f));
        if (transform.position.x >= maximumposXaxis)
        {
            right = false;
            sprite.flipX = false;
        }
        else if (transform.position.x <= minimumposXaxis)
        {
            right = true;
            sprite.flipX = true;
        }
    }
   
}
