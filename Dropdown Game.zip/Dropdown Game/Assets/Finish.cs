using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Finish : MonoBehaviour
{
    public static Text finishText;

    // Start is called before the first frame update
    void Start()
    {
        finishText = GetComponent<Text>();
        finishText.text = "Well Done! Press 'R' to play again.";
        finishText.enabled = false;
    }

    // Update is called once per frame
    private void Update()
    {
        
        
        if (Input.GetKeyDown(KeyCode.R))
        {
            RestartGame();
            Life.checkDie = false;
            finishText.enabled = false;
        }
       
    }


    private void RestartGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}

