using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Over : MonoBehaviour
{
    private Text overText;
    

    private void Start()
    {
        overText = GetComponent<Text>();
        overText.text = "Game Over! Press 'R' to try again.";
        overText.enabled = false;
        EndGame.all = false;
    }

    private void Update()
    {
       if(Life.checkDie == true && EndGame.all == false)
        {
            overText.text = "Game Over! Press 'R' to try again.";
            overText.enabled = true;
            if(Input.GetKeyDown(KeyCode.R))
            {
                RestartGame();
                Life.checkDie = false;
                overText.enabled = false;
            }
           
        }
    }

    private void RestartGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
