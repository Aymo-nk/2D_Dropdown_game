using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    private Rigidbody2D rb;
    [SerializeField] public float playerSpeed = 1f;
    private bool movingForward = false;
    
    private SpriteRenderer sprite;
    
    private enum MovementState {running, dropping, die }
    
    private Animator anim;
    


  


    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        sprite = GetComponent<SpriteRenderer>();
        anim = GetComponent<Animator>();
    }

    
    private void Update()
    {
       
        if (Input.GetKeyDown(KeyCode.Space) && Life.checkDie == false)
        {
            movingForward = true;
            transform.rotation = Quaternion.Euler(0f, 10f, 0f);
        }

        
        if (Input.GetKeyDown(KeyCode.RightArrow) && Life.checkDie == false)
        {
            transform.rotation = Quaternion.Euler(0f, 10f, 0f);
            sprite.flipX = false;
        }

        
        if (Input.GetKeyDown(KeyCode.LeftArrow) && Life.checkDie == false)
        {
            transform.rotation = Quaternion.Euler(0f, -10f, 0f);
            sprite.flipX = true;
        }

        
        if (movingForward && Life.checkDie == false )
        {
            transform.Translate(Vector3.forward * playerSpeed * Time.deltaTime);
        }

        UpdateAnimantionState();
    }

    private void UpdateAnimantionState()
    {
        MovementState state = MovementState.running;

        if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.LeftArrow))
        {
            state = MovementState.running;
        }
        else if(rb.velocity.y < -.1f)
        {
            state = MovementState.dropping;
        }
        


        anim.SetInteger("state", (int)state);
    }
}

