using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Points : MonoBehaviour
{

    private int count = 0;

    [SerializeField] private Text score;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.CompareTag("Counter"))
        {
            Destroy(collision.gameObject);
            count++;
            score.text = "Score: " + count;
        }
    }
}
